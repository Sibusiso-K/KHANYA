# REEFPRINT/KHANYA report evidence package (v17, 8 October 2026)

Supports report v17 (report/main.tex). Planning allowances are not quotes; software checks are not accuracy results.

## Contents
- PILOT_COST_LEDGER.csv: every pilot cost line with tranche, proposed payer, release condition, commitment point,
  cancellation exposure and contingency; P0 broken into its six allowances (cap R210,000, outside the pilot total).
  Regenerate with `python make_ledger.py` (from report/). Tranche totals: L1 R1,748,267; L2 R2,720,533; R-H R472,320;
  R-M R787,200; reserves R1.679-2.171M; B1 R0.57-0.90M; B2 R2.71-4.35M; pilot R10.69-13.15M; with P0 R10.90-13.36M.
  Released cash = tranches released at their gates; committed/non-recoverable = orders placed, notice periods, lease
  deposit and cancellation; avoidable = unreleased tranches and reserves.
- replay_envelope.py / replay_envelope.json: envelope-clipped feed-rate replay (report Section 4.2).
  Inputs: inputs/training/... extracted verbatim from commit ab333071d184fa8f853ea96e78fd81a2f948d547 (branch codex/pwa-phase-roadmap).
  Policy: deployed policy of training/value-chain-20261002/value_chain.py (refused -> fold P90; borderline ->
  max(bound, P90); pass -> one-sided 90% bound); feed clipped to 85-110% of design (hardness clipped to
  [P90/1.10, P90/0.85]). Throughput vs blind P90 = sum(P90)/sum(Wi_used) - 1. Bootstrap: units = samples
  (no drill-hole ids), B = 4000, numpy default_rng seed 1, percentile 2.5/97.5. Rounded to 0.1 percentage point.
  Result: unclipped 1.93% [0.91, 2.91] (reproduces the committed value);
  clipped 1.75% [0.79, 2.66].
  Run by Claude on 8 Oct 2026 with Python 3.13.14; the script reads inputs with `git show` from the repository root.
- EVIDENCE_MANIFEST.md: checkpoint hashes, release index (historical model, tested local build, public static demo,
  research datasets) and local packages, with items still missing marked.
- SHA256SUMS: checksums of every file above.
